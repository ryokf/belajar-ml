from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
import pandas as pd
import matplotlib.pyplot as plt

# def polynomial_regression():

def train_linear_regression(x, y):
    X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)
    
    model = LinearRegression()
    model.fit(X_train, y_train)
    
    return model, X_test, y_test

def evaluate_model(model, X_test, y_test):
    y_pred = model.predict(X_test)
    
    plt.figure(figsize=(10,6))
    plt.scatter(y_test, y_pred, color="blue")
    plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--', lw=2)
    plt.xlabel('harga asli')
    plt.ylabel('harga prediksi')

    plt.show()

    score = r2_score(y_test, y_pred)
    print(f"R2 Score (Akurasi): {score:.2f}")